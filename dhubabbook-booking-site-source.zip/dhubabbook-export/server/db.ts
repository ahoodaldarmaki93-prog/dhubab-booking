import { and, asc, eq, gte, lte, like, or, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, Reservation, reservations, User, users } from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;
  type TextField = (typeof textFields)[number];

  const assignNullable = (field: TextField) => {
    const value = user[field];
    if (value === undefined) return;
    const normalized = value ?? null;
    values[field] = normalized;
    updateSet[field] = normalized;
  };
  textFields.forEach(assignNullable);

  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  if (!values.lastSignedIn) values.lastSignedIn = new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string): Promise<User | undefined> {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

/** Additive, idempotent preparation for the feature table in managed environments. */
export async function ensureReservationSchema() {
  const db = await getDb();
  if (!db) return;
  await db.execute(sql.raw(`
    CREATE TABLE IF NOT EXISTS reservations (
      id INT AUTO_INCREMENT PRIMARY KEY,
      bookingDate VARCHAR(10) NOT NULL,
      lesson INT NOT NULL,
      teacherName VARCHAR(120) NOT NULL,
      grade VARCHAR(80) NOT NULL,
      lessonTitle VARCHAR(200) NOT NULL DEFAULT '',
      email VARCHAR(320) NULL,
      notes TEXT NULL,
      resourceOptions VARCHAR(255) NOT NULL,
      createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY reservations_booking_slot_unique (bookingDate, lesson)
    )
  `));
  try {
    await db.execute(sql.raw(`ALTER TABLE reservations ADD COLUMN email VARCHAR(320) NULL AFTER grade`));
  } catch (error) {
    const candidate = error as { message?: string; cause?: { code?: string; message?: string } };
    const message = [candidate?.message, candidate?.cause?.code, candidate?.cause?.message, String(error)]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
    if (!message.includes("duplicate column") && !message.includes("er_dup_fieldname") && !message.includes("already exists")) throw error;
  }
  try {
    await db.execute(sql.raw(`ALTER TABLE reservations ADD COLUMN lessonTitle VARCHAR(200) NOT NULL DEFAULT '' AFTER grade`));
  } catch (error) {
    const candidate = error as { message?: string; cause?: { code?: string; message?: string } };
    const message = [candidate?.message, candidate?.cause?.code, candidate?.cause?.message, String(error)]
      .filter(Boolean)
      .join(" ")
      .toLowerCase();
    if (!message.includes("duplicate column") && !message.includes("er_dup_fieldname") && !message.includes("already exists")) throw error;
  }
}

export class ReservationConflictError extends Error {
  constructor() {
    super("RESERVATION_SLOT_TAKEN");
    this.name = "ReservationConflictError";
  }
}

export type ReservationInput = {
  bookingDate: string;
  lesson: number;
  teacherName: string;
  grade: string;
  lessonTitle: string;
  email?: string;
  notes?: string;
  resourceOptions: string[];
};

function isDuplicateError(error: unknown) {
  const candidate = error as {
    code?: string;
    errno?: number;
    message?: string;
    cause?: { code?: string; errno?: number; message?: string };
  };
  const text = [candidate?.message, candidate?.cause?.message, JSON.stringify(error)]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
  return (
    candidate?.code === "ER_DUP_ENTRY" ||
    candidate?.errno === 1062 ||
    candidate?.cause?.code === "ER_DUP_ENTRY" ||
    candidate?.cause?.errno === 1062 ||
    text.includes("duplicate entry") ||
    text.includes("er_dup_entry")
  );
}

function mapReservation(row: Reservation) {
  let resourceOptions: string[] = [];
  try {
    const parsed = JSON.parse(row.resourceOptions);
    if (Array.isArray(parsed)) resourceOptions = parsed.filter(value => typeof value === "string");
  } catch {
    resourceOptions = row.resourceOptions ? [row.resourceOptions] : [];
  }
  return { ...row, resourceOptions };
}

export async function getPublicAvailability(bookingDate: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const result = await db
    .select({ lesson: reservations.lesson })
    .from(reservations)
    .where(eq(reservations.bookingDate, bookingDate));
  return result.map(item => item.lesson);
}

export async function createReservation(input: ReservationInput) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  try {
    const [result] = await db.insert(reservations).values({
      bookingDate: input.bookingDate,
      lesson: input.lesson,
      teacherName: input.teacherName,
      grade: input.grade,
      lessonTitle: input.lessonTitle,
      email: input.email || null,
      notes: input.notes || null,
      resourceOptions: JSON.stringify(input.resourceOptions),
    });
    return { id: Number(result.insertId) };
  } catch (error) {
    if (isDuplicateError(error)) throw new ReservationConflictError();
    throw error;
  }
}

export async function listReservations(params: { from: string; to: string; search?: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const filters = [gte(reservations.bookingDate, params.from), lte(reservations.bookingDate, params.to)];
  const search = params.search?.trim();
  if (search) {
    filters.push(
      or(
        like(reservations.teacherName, `%${search}%`),
        like(reservations.grade, `%${search}%`),
        like(reservations.lessonTitle, `%${search}%`),
        like(reservations.notes, `%${search}%`),
      )!,
    );
  }
  const result = await db
    .select()
    .from(reservations)
    .where(and(...filters))
    .orderBy(asc(reservations.bookingDate), asc(reservations.lesson));
  return result.map(mapReservation);
}

export async function updateReservation(id: number, input: ReservationInput) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  try {
    await db
      .update(reservations)
      .set({
        bookingDate: input.bookingDate,
        lesson: input.lesson,
        teacherName: input.teacherName,
        grade: input.grade,
        lessonTitle: input.lessonTitle,
        email: input.email || null,
        notes: input.notes || null,
        resourceOptions: JSON.stringify(input.resourceOptions),
        updatedAt: new Date(),
      })
      .where(eq(reservations.id, id));
  } catch (error) {
    if (isDuplicateError(error)) throw new ReservationConflictError();
    throw error;
  }
}

export async function deleteReservation(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(reservations).where(eq(reservations.id, id));
}
