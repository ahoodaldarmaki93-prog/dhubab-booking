import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { getSessionCookieOptions } from "./_core/cookies";
import { COOKIE_NAME } from "@shared/const";
import { systemRouter } from "./_core/systemRouter";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import {
  createReservation,
  deleteReservation,
  getPublicAvailability,
  listReservations,
  ReservationConflictError,
  updateReservation,
} from "./db";

const resourceOption = z.enum(["القراءة", "استخدام الأجهزة", "استخدام الشاشة", "أخرى"]);
const reservationInput = z.object({
  bookingDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "التاريخ غير صحيح"),
  lesson: z.number().int().min(1).max(7),
  teacherName: z.string().trim().min(2).max(120),
  grade: z.string().trim().min(1).max(80),
  lessonTitle: z.string().trim().min(2, "اكتبي عنوان الدرس أو المادة").max(200),
  email: z.string().trim().email("البريد الإلكتروني غير صحيح").max(320).optional().or(z.literal("")),
  notes: z.string().trim().max(1000).optional().or(z.literal("")),
  resourceOptions: z.array(resourceOption).min(1).max(2),
});

const dateRange = z.object({
  from: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  to: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  search: z.string().max(120).optional(),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  reservations: router({
    availability: publicProcedure
      .input(z.object({ bookingDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }))
      .query(({ input }) => getPublicAvailability(input.bookingDate)),
    create: publicProcedure.input(reservationInput).mutation(async ({ input }) => {
      try {
        return await createReservation(input);
      } catch (error) {
        if (error instanceof ReservationConflictError) {
          throw new TRPCError({ code: "CONFLICT", message: "هذه الحصة محجوزة مسبقًا، اختاري حصة أخرى." });
        }
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "تعذر حفظ الحجز الآن. حاولي مرة أخرى." });
      }
    }),
    adminList: adminProcedure.input(dateRange).query(({ input }) => listReservations(input)),
    adminUpdate: adminProcedure.input(z.object({ id: z.number().int().positive(), data: reservationInput })).mutation(async ({ input }) => {
      try {
        await updateReservation(input.id, input.data);
        return { success: true } as const;
      } catch (error) {
        if (error instanceof ReservationConflictError) {
          throw new TRPCError({ code: "CONFLICT", message: "التعديل تعارض مع حجز موجود في اليوم والحصة نفسيهما." });
        }
        throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: "تعذر تعديل الحجز." });
      }
    }),
    adminDelete: adminProcedure.input(z.object({ id: z.number().int().positive() })).mutation(async ({ input }) => {
      await deleteReservation(input.id);
      return { success: true } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
