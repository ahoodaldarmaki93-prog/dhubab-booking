import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { CalendarDays, Check, ChevronLeft, Clock3, FileText, LibraryBig, LockKeyhole, Monitor, NotebookPen, Sparkles, Tablet } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { toast } from "sonner";

const RESOURCE_OPTIONS = ["القراءة", "استخدام الأجهزة", "استخدام الشاشة", "أخرى"] as const;
type ResourceOption = (typeof RESOURCE_OPTIONS)[number];

const localDate = () => {
  const now = new Date();
  const offset = now.getTimezoneOffset();
  return new Date(now.getTime() - offset * 60_000).toISOString().slice(0, 10);
};

const formatArabicDate = (value: string) =>
  new Intl.DateTimeFormat("ar-OM", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  }).format(new Date(`${value}T12:00:00`));

const lessonLabels = ["الأولى", "الثانية", "الثالثة", "الرابعة", "الخامسة", "السادسة", "السابعة"];

export default function Home() {
  const today = useMemo(localDate, []);
  const [bookingDate, setBookingDate] = useState(today);
  const [lesson, setLesson] = useState(1);
  const [teacherName, setTeacherName] = useState("");
  const [grade, setGrade] = useState("");
  const [lessonTitle, setLessonTitle] = useState("");
  const [email, setEmail] = useState("");
  const [notes, setNotes] = useState("");
  const [resourceOptions, setResourceOptions] = useState<ResourceOption[]>([]);

  const availability = trpc.reservations.availability.useQuery({ bookingDate });
  const utils = trpc.useUtils();
  const createReservation = trpc.reservations.create.useMutation({
    onSuccess: () => {
      toast.success("تم حفظ الحجز بنجاح", { description: "نتمنى لكِ حصة تعليمية ممتعة في مركز مصادر التعلّم." });
      setTeacherName("");
      setGrade("");
      setLessonTitle("");
      setEmail("");
      setNotes("");
      setResourceOptions([]);
      utils.reservations.availability.invalidate({ bookingDate });
    },
    onError: error => {
      if (error.data?.code === "CONFLICT") {
        toast.error("الحصة محجوزة مسبقًا", { description: "اختاري حصة أخرى أو غيّري تاريخ الحجز." });
        utils.reservations.availability.invalidate({ bookingDate });
      } else {
        toast.error(error.message || "تعذر حفظ الحجز");
      }
    },
  });

  const bookedLessons = useMemo(() => new Set(availability.data ?? []), [availability.data]);

  const toggleOption = (option: ResourceOption) => {
    setResourceOptions(current => {
      if (current.includes(option)) return current.filter(item => item !== option);
      if (current.length >= 2) {
        toast.info("يمكن اختيار خيارين فقط", { description: "أزيلي أحد الخيارات أولًا ثم اختاري غيره." });
        return current;
      }
      return [...current, option];
    });
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (bookedLessons.has(lesson)) {
      toast.error("الحصة محجوزة مسبقًا", { description: "اختاري حصة متاحة من الجدول." });
      return;
    }
    if (resourceOptions.length === 0) {
      toast.error("اختاري نوع الاستخدام", { description: "يمكن اختيار خيار واحد أو خيارين." });
      return;
    }
    createReservation.mutate({ bookingDate, lesson, teacherName, grade, lessonTitle, email, notes, resourceOptions });
  };

  return (
    <div className="site-shell">
      <header className="topbar page-width">
        <div className="header-ministry official-logo"><img src="/assets/ministry-education-oman-new.png" alt="وزارة التعليم" /></div>
        <a className="brand-lockup centered-brand" href="/" aria-label="الصفحة الرئيسية"><span className="school-mark school-mark-center"><img src="/assets/school-logo-new.png" alt="شعار مدرسة ضباب" /></span></a>
        <div className="header-vision official-logo"><img src="/assets/oman-vision-2040-cropped.png" alt="رؤية عُمان 2040" /></div>
      </header>

      <main className="page-width main-content">
        <section className="hero-grid">
          <div className="hero-card">
            <div className="eyebrow"><Sparkles size={16} /> مركز مصادر التعلّم</div>
            <h1>احجزي مساحتكِ للتعلّم<br /><em>بكل هدوء وسهولة</em></h1>
            <p className="hero-lead">نظام حجز بسيط يساعدكِ على تنظيم حصتكِ في مركز مصادر التعلّم، من القراءة إلى التجربة الرقمية.</p>
            <div className="hero-meta">
              <div className="date-chip"><CalendarDays size={19} /><span><b>{formatArabicDate(bookingDate)}</b><small>التاريخ المختار للحجز</small></span></div>
              <div className="specialist-chip"><span className="avatar-initial">ع</span><span><b>عهود الدرمكي</b><small>أخصائية مصادر التعلّم</small></span></div>
            </div>
            <div className="hero-pattern" aria-hidden="true"><span /><span /><span /><span /><span /></div>
          </div>
          <aside className="welcome-card">
            <div className="welcome-icon"><LibraryBig size={25} /></div>
            <span className="mini-label">مساحتكِ جاهزة</span>
            <h2>اختاري وقتكِ…<br />والباقي علينا</h2>
            <p>تظهر الحصص المحجوزة باللون الهادئ، وتبقى الخيارات المتاحة بين يديكِ.</p>
            <a href="#booking" className="text-link">ابدئي الحجز <ChevronLeft size={17} /></a>
            <div className="welcome-line" />
            <div className="welcome-note"><LockKeyhole size={17} /><span>كل حصة تُحجز مرة واحدة فقط</span></div>
          </aside>
        </section>

        <section id="booking" className="booking-layout">
          <div className="booking-card">
            <div className="section-heading">
              <div><span className="section-kicker">خطوة واحدة تفصلكِ عن الحجز</span><h2>بيانات الحجز</h2></div>
              <span className="step-badge">01 <span>/ 03</span></span>
            </div>
            <form onSubmit={submit}>
              <div className="form-grid two-cols">
                <label className="field"><span>تاريخ الحجز</span><div className="input-with-icon"><CalendarDays size={18} /><input type="date" min={today} value={bookingDate} onChange={event => setBookingDate(event.target.value)} required /></div></label>
                <label className="field"><span>اسم المعلمة</span><div className="input-with-icon"><NotebookPen size={18} /><input value={teacherName} onChange={event => setTeacherName(event.target.value)} placeholder="اكتبي الاسم هنا" minLength={2} required /></div></label>
                <label className="field"><span>الصف / الشعبة</span><div className="input-with-icon"><FileText size={18} /><input value={grade} onChange={event => setGrade(event.target.value)} placeholder="مثال: الصف الخامس / أ" required /></div></label>
                <label className="field"><span>عنوان الدرس / المادة</span><div className="input-with-icon"><NotebookPen size={18} /><input value={lessonTitle} onChange={event => setLessonTitle(event.target.value)} placeholder="مثال: مهارات البحث أو اللغة العربية" minLength={2} maxLength={200} required /></div></label>
                <label className="field"><span>البريد الإلكتروني <small>اختياري — لن يصلكِ تنبيه إذا تُرك فارغًا</small></span><div className="input-with-icon"><FileText size={18} /><input type="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="name@school.om" /></div></label>
              </div>

              <div className="field lesson-field"><span>اختاري الحصة <small>الحصة المتاحة تظهر بلون أخضر</small></span><div className="lesson-grid">
                {lessonLabels.map((label, index) => {
                  const number = index + 1;
                  const isBooked = bookedLessons.has(number);
                  return <button type="button" key={label} className={`lesson-option ${lesson === number ? "selected" : ""} ${isBooked ? "booked" : ""}`} disabled={isBooked} onClick={() => setLesson(number)}><span>{label}</span><small>{isBooked ? "محجوزة" : "متاحة"}</small></button>;
                })}
              </div></div>

              <div className="field"><span>نوع الاستخدام <small>يمكن اختيار خيارين فقط</small></span><div className="resource-grid">
                {RESOURCE_OPTIONS.map(option => {
                  const active = resourceOptions.includes(option);
                  const Icon = option === "القراءة" ? LibraryBig : option === "استخدام الأجهزة" ? Tablet : option === "استخدام الشاشة" ? Monitor : FileText;
                  return <button type="button" key={option} className={`resource-option ${active ? "active" : ""}`} onClick={() => toggleOption(option)}><span className="resource-icon"><Icon size={19} /></span><span>{option}</span>{active && <Check className="resource-check" size={17} />}</button>;
                })}
              </div></div>

              <label className="field"><span>ملاحظات <small>اختياري</small></span><textarea value={notes} onChange={event => setNotes(event.target.value)} placeholder="أضيفي أي تجهيزات أو ملاحظات تساعدنا على الاستعداد…" rows={3} maxLength={1000} /></label>
              <div className="form-footer"><p><Clock3 size={16} /> سيتم تثبيت الحجز فور الضغط على الزر</p><Button type="submit" className="submit-button" disabled={createReservation.isPending}>{createReservation.isPending ? "جارٍ الحفظ…" : "تأكيد الحجز"}<ChevronLeft size={18} /></Button></div>
            </form>
          </div>

          <aside className="availability-card">
            <div className="availability-top"><div><span className="section-kicker">نظرة سريعة</span><h2>جدول الحصص</h2></div><div className="live-dot"><span /> مباشر</div></div>
            <p className="availability-date">{formatArabicDate(bookingDate)}</p>
            <div className="availability-list">{lessonLabels.map((label, index) => { const number = index + 1; const isBooked = bookedLessons.has(number); return <div key={label} className={`availability-row ${isBooked ? "is-booked" : ""} ${lesson === number && !isBooked ? "is-selected" : ""}`}><span className="lesson-number">0{number}</span><span className="lesson-name">الحصة {label}</span><span className="availability-status">{isBooked ? "محجوزة" : "متاحة"}</span></div>; })}</div>
            <div className="availability-footer"><span className="status-key"><i className="available-dot" /> متاحة</span><span className="status-key"><i className="booked-dot" /> محجوزة</span></div>
          </aside>
        </section>
      </main>

      <footer className="site-footer page-width"><span>مركز مصادر التعلّم · مدرسة ضباب</span><span>صُمّم بعناية لخدمة معلماتنا</span><span className="supervised-by">بإشراف مديرة المدرسة / ناهد الغزيلي</span><a href="/admin">دخول المسؤولة</a></footer>
    </div>
  );
}
