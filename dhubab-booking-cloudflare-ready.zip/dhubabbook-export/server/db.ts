export type Reservation = {
  id: number; bookingDate: string; lesson: number; teacherName: string; grade: string;
  lessonTitle: string; email: string | null; notes: string | null; resourceOptions: string[];
  createdAt?: string; updatedAt?: string;
};

let DB: D1Database | null = null;
export function initDatabase(db: D1Database) { DB = db; }
function getDb() { if (!DB) throw new Error('Database is not available'); return DB; }

export async function ensureReservationSchema() {
  const db = getDb();
  await db.batch([
    db.prepare(`CREATE TABLE IF NOT EXISTS reservations (id INTEGER PRIMARY KEY AUTOINCREMENT, bookingDate TEXT NOT NULL, lesson INTEGER NOT NULL, teacherName TEXT NOT NULL, grade TEXT NOT NULL, lessonTitle TEXT NOT NULL DEFAULT '', email TEXT, notes TEXT, resourceOptions TEXT NOT NULL, createdAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updatedAt TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(bookingDate, lesson))`),
  ]);
}

export class ReservationConflictError extends Error { constructor(){ super('RESERVATION_SLOT_TAKEN'); this.name='ReservationConflictError'; } }
export type ReservationInput = { bookingDate:string; lesson:number; teacherName:string; grade:string; lessonTitle:string; email?:string; notes?:string; resourceOptions:string[] };
function map(row: any): Reservation { let options:string[]=[]; try { const x=JSON.parse(row.resourceOptions); if(Array.isArray(x)) options=x.filter((v:any)=>typeof v==='string'); } catch {} return {...row, resourceOptions: options}; }

export async function getPublicAvailability(bookingDate:string) { const {results}=await getDb().prepare('SELECT lesson FROM reservations WHERE bookingDate=? ORDER BY lesson').bind(bookingDate).all<{lesson:number}>(); return results.map(r=>r.lesson); }
export async function createReservation(i:ReservationInput) { const r=await getDb().prepare('INSERT INTO reservations (bookingDate,lesson,teacherName,grade,lessonTitle,email,notes,resourceOptions) VALUES (?,?,?,?,?,?,?,?)').bind(i.bookingDate,i.lesson,i.teacherName,i.grade,i.lessonTitle,i.email||null,i.notes||null,JSON.stringify(i.resourceOptions)).run(); if(!r.success){throw new Error('insert failed')} return {id:Number(r.meta.last_row_id)}; }
export async function listReservations(p:{from:string;to:string;search?:string}) { let sql='SELECT * FROM reservations WHERE bookingDate>=? AND bookingDate<=?'; const args:any[]=[p.from,p.to]; if(p.search?.trim()){sql+=' AND (teacherName LIKE ? OR grade LIKE ? OR lessonTitle LIKE ? OR notes LIKE ?)'; const q=`%${p.search.trim()}%`; args.push(q,q,q,q);} sql+=' ORDER BY bookingDate ASC, lesson ASC'; const {results}=await getDb().prepare(sql).bind(...args).all(); return results.map(map); }
export async function updateReservation(id:number,i:ReservationInput){const r=await getDb().prepare('UPDATE reservations SET bookingDate=?,lesson=?,teacherName=?,grade=?,lessonTitle=?,email=?,notes=?,resourceOptions=?,updatedAt=CURRENT_TIMESTAMP WHERE id=?').bind(i.bookingDate,i.lesson,i.teacherName,i.grade,i.lessonTitle,i.email||null,i.notes||null,JSON.stringify(i.resourceOptions),id).run(); if(!r.success) throw new Error('update failed');}
export async function deleteReservation(id:number){await getDb().prepare('DELETE FROM reservations WHERE id=?').bind(id).run();}
