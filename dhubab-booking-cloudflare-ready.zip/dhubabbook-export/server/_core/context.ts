import type { Env } from '../../worker';
import { getAdminUserFromRequest, type AppUser } from './session';

export type TrpcContext = {
  req: Request;
  env: Env;
  user: AppUser | null;
  responseHeaders: Headers;
};

export async function createContext(opts: { req: Request; env: Env }): Promise<TrpcContext> {
  return { req: opts.req, env: opts.env, user: await getAdminUserFromRequest(opts.req, opts.env.SESSION_SECRET), responseHeaders: new Headers() };
}
