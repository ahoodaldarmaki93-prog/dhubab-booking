import { initTRPC, TRPCError } from '@trpc/server';
import superjson from 'superjson';
import type { TrpcContext } from './context';
import { clearSessionCookie, createSession, sessionCookie } from './session';

const t=initTRPC.context<TrpcContext>().create({transformer:superjson});
export const router=t.router;
export const publicProcedure=t.procedure;
export const adminProcedure=t.procedure.use(t.middleware(async ({ctx,next})=>{if(!ctx.user) throw new TRPCError({code:'UNAUTHORIZED',message:'تسجيل الدخول مطلوب لإدارة الحجوزات.'}); return next({ctx:{...ctx,user:ctx.user}});}));
export { clearSessionCookie, createSession, sessionCookie };
