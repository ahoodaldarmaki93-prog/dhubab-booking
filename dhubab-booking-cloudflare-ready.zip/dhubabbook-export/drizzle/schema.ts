export type User = { id:number; openId:string; name:string|null; email:string|null; role:'admin' };
export type InsertUser = Partial<User>;
export type Reservation = import('../server/db').Reservation;
export type InsertReservation = Omit<Reservation,'id'>;
