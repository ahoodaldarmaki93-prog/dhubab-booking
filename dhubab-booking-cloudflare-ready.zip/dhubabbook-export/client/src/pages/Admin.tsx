import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { CalendarDays, ChevronLeft, Download, Edit3, FileText, LogIn, LogOut, Search, ShieldCheck, Trash2, UsersRound, X } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { toast } from "sonner";

const OPTIONS = ["القراءة", "استخدام الأجهزة", "استخدام الشاشة", "أخرى"] as const;
type Option = (typeof OPTIONS)[number];
type Reservation = { id: number; bookingDate: string; lesson: number; teacherName: string; grade: string; lessonTitle: string; email: string | null; notes: string | null; resourceOptions: string[] };

const localDate = () => { const now = new Date(); const offset = now.getTimezoneOffset(); return new Date(now.getTime() - offset * 60_000).toISOString().slice(0, 10); };
const addDays = (value: string, days: number) => { const date = new Date(`${value}T12:00:00`); date.setDate(date.getDate() + days); return date.toISOString().slice(0, 10); };
const formatDate = (value: string) => new Intl.DateTimeFormat("ar-OM", { day: "numeric", month: "long", year: "numeric" }).format(new Date(`${value}T12:00:00`));
const formatWeek = (from: string, to: string) => `${formatDate(from)} – ${formatDate(to)}`;

const exportReservationsToExcel = async (reservations: Reservation[], view: "day" | "week", from: string, to: string) => {
  const XLSX = await import("xlsx");
  const rows = reservations.map(item => ({
    "التاريخ": item.bookingDate,
    "الحصة": `الحصة ${item.lesson}`,
    "اسم المعلمة": item.teacherName,
    "الصف / الشعبة": item.grade,
    "عنوان الدرس / المادة": item.lessonTitle,
    "البريد الإلكتروني": item.email || "",
    "نوع الاستخدام": item.resourceOptions.join("، "),
    "الملاحظات": item.notes || "",
  }));
  const worksheet = XLSX.utils.json_to_sheet(rows);
  worksheet["!cols"] = [
    { wch: 14 }, { wch: 12 }, { wch: 24 }, { wch: 20 }, { wch: 32 }, { wch: 28 }, { wch: 28 }, { wch: 42 },
  ];
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "الحجوزات");
  const label = view === "day" ? `يومية-${from}` : `أسبوعية-${from}-${to}`;
  XLSX.writeFile(workbook, `حجوزات-${label}.xlsx`);
  toast.success("تم تصدير ملف Excel", { description: `تم تصدير ${reservations.length} حجز.` });
};


const escapeHtml = (value: string) => value.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[character] ?? character));

const printReservationsToPdf = (reservations: Reservation[], view: "day" | "week", from: string, to: string) => {
  const reportWindow = window.open("", "_blank");
  if (!reportWindow) {
    toast.error("تعذّر فتح التقرير", { description: "اسمحي بالنوافذ المنبثقة ثم حاولي مرة أخرى." });
    return;
  }
  const label = view === "day" ? `تقرير الحجوزات اليومية – ${formatDate(from)}` : `تقرير الحجوزات الأسبوعية – ${formatWeek(from, to)}`;
  const rows = reservations.map(item => `<tr><td>${escapeHtml(item.bookingDate)}</td><td>الحصة ${item.lesson}</td><td>${escapeHtml(item.teacherName)}</td><td>${escapeHtml(item.grade)}</td><td>${escapeHtml(item.lessonTitle || "—")}</td><td>${escapeHtml(item.resourceOptions.join("، "))}</td><td>${escapeHtml(item.notes || "—")}</td></tr>`).join("");
  reportWindow.document.write(`<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>${escapeHtml(label)}</title><style>body{font-family:Arial,Tahoma,sans-serif;color:#203b5d;margin:32px;direction:rtl}h1{font-size:24px;margin:0 0 8px;color:#2c5e8a}p{color:#64748b;margin:0 0 22px}table{border-collapse:collapse;width:100%;font-size:12px}th,td{border:1px solid #d9e5f0;padding:9px;text-align:right;vertical-align:top}th{background:#eaf4fb;color:#2c5e8a}tr:nth-child(even){background:#f8fbfd}.signature{margin-top:28px;color:#2c5e8a;font-weight:700}@media print{body{margin:15mm}button{display:none}}</style></head><body><h1>${escapeHtml(label)}</h1><p>مركز مصادر التعلّم – مدرسة ضباب للتعليم الأساسي 1–12<br>إجمالي الحجوزات: ${reservations.length}</p><table><thead><tr><th>التاريخ</th><th>الحصة</th><th>المعلمة</th><th>الصف / الشعبة</th><th>عنوان الدرس / المادة</th><th>نوع الاستخدام</th><th>الملاحظات</th></tr></thead><tbody>${rows || '<tr><td colspan="7">لا توجد حجوزات في هذا العرض.</td></tr>'}</tbody></table><div class="signature">أخصائية مصادر التعلم / عهود الدرمكي</div></body></html>`);
  reportWindow.document.close();
  reportWindow.focus();
  window.setTimeout(() => reportWindow.print(), 250);
  toast.success("تم تجهيز تقرير PDF", { description: "اختاري «حفظ كملف PDF» من نافذة الطباعة." });
};

function EditForm({ reservation, onClose, onSaved }: { reservation: Reservation; onClose: () => void; onSaved: () => void }) {
  const [date, setDate] = useState(reservation.bookingDate);
  const [lesson, setLesson] = useState(String(reservation.lesson));
  const [teacher, setTeacher] = useState(reservation.teacherName);
  const [grade, setGrade] = useState(reservation.grade);
  const [lessonTitle, setLessonTitle] = useState(reservation.lessonTitle ?? "");
  const [email, setEmail] = useState(reservation.email ?? "");
  const [notes, setNotes] = useState(reservation.notes ?? "");
  const [options, setOptions] = useState<Option[]>(reservation.resourceOptions.filter(item => OPTIONS.includes(item as Option)) as Option[]);
  const update = trpc.reservations.adminUpdate.useMutation({ onSuccess: () => { toast.success("تم تعديل الحجز"); onSaved(); onClose(); }, onError: error => toast.error(error.message) });
  const toggle = (option: Option) => setOptions(current => current.includes(option) ? current.filter(item => item !== option) : current.length < 2 ? [...current, option] : current);
  const submit = (event: FormEvent) => { event.preventDefault(); if (!lessonTitle.trim()) return toast.error("اكتبي عنوان الدرس أو المادة"); if (!options.length) return toast.error("اختاري نوع استخدام واحد على الأقل"); update.mutate({ id: reservation.id, data: { bookingDate: date, lesson: Number(lesson), teacherName: teacher, grade, lessonTitle, email, notes, resourceOptions: options } }); };
  return <div className="modal-backdrop"><div className="edit-modal"><div className="modal-head"><div><span className="section-kicker">تحديث الحجز</span><h2>تعديل بيانات الحصة</h2></div><button className="icon-button" onClick={onClose} aria-label="إغلاق"><X size={19} /></button></div><form onSubmit={submit} className="edit-form"><div className="form-grid two-cols"><label className="field"><span>التاريخ</span><input type="date" value={date} onChange={event => setDate(event.target.value)} required /></label><label className="field"><span>الحصة</span><select value={lesson} onChange={event => setLesson(event.target.value)}>{[1,2,3,4,5,6,7].map(value => <option key={value} value={value}>الحصة {value}</option>)}</select></label><label className="field"><span>اسم المعلمة</span><input value={teacher} onChange={event => setTeacher(event.target.value)} required /></label><label className="field"><span>الصف / الشعبة</span><input value={grade} onChange={event => setGrade(event.target.value)} required /></label><label className="field"><span>عنوان الدرس / المادة</span><input value={lessonTitle} onChange={event => setLessonTitle(event.target.value)} placeholder="مثال: مهارات البحث" required /></label><label className="field"><span>البريد الإلكتروني <small>اختياري للتذكير</small></span><input type="email" value={email} onChange={event => setEmail(event.target.value)} placeholder="name@school.om" /></label></div><div className="field"><span>نوع الاستخدام</span><div className="resource-grid compact">{OPTIONS.map(option => <button type="button" key={option} className={`resource-option ${options.includes(option) ? "active" : ""}`} onClick={() => toggle(option)}>{option}</button>)}</div></div><label className="field"><span>ملاحظات</span><textarea value={notes} onChange={event => setNotes(event.target.value)} rows={3} /></label><div className="modal-actions"><Button type="button" variant="outline" onClick={onClose}>إلغاء</Button><Button type="submit" disabled={update.isPending}>{update.isPending ? "جارٍ التحديث…" : "حفظ التعديل"}</Button></div></form></div></div>;
}

export default function Admin() {
  const { user, loading, logout, login } = useAuth();
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const today = useMemo(localDate, []);
  const [anchorDate, setAnchorDate] = useState(today);
  const [view, setView] = useState<"day" | "week">("day");
  const [search, setSearch] = useState("");
  const [editing, setEditing] = useState<Reservation | null>(null);
  const range = useMemo(() => { if (view === "day") return { from: anchorDate, to: anchorDate }; const day = new Date(`${anchorDate}T12:00:00`).getDay(); const from = addDays(anchorDate, -day); return { from, to: addDays(from, 6) }; }, [anchorDate, view]);
  const isAdmin = user?.role === "admin";
  const query = trpc.reservations.adminList.useQuery({ ...range, search }, { enabled: isAdmin, refetchOnWindowFocus: false });
  const utils = trpc.useUtils();
  const remove = trpc.reservations.adminDelete.useMutation({ onSuccess: () => { toast.success("تم إلغاء الحجز"); utils.reservations.adminList.invalidate(); }, onError: error => toast.error(error.message) });
  const reservations = (query.data ?? []) as Reservation[];
  const chartData = useMemo(() => {
    if (view === "day") return [1, 2, 3, 4, 5, 6, 7].map(lesson => ({ label: `ح${lesson}`, count: reservations.filter(item => item.lesson === lesson).length }));
    return Array.from({ length: 7 }, (_, index) => { const date = addDays(range.from, index); return { label: new Intl.DateTimeFormat("ar-OM", { weekday: "short" }).format(new Date(`${date}T12:00:00`)), count: reservations.filter(item => item.bookingDate === date).length }; });
  }, [range.from, reservations, view]);
  const maxChartCount = Math.max(1, ...chartData.map(item => item.count));
  const usageStats = useMemo(() => OPTIONS.map(option => ({ option, count: reservations.filter(item => item.resourceOptions.includes(option)).length })).sort((a, b) => b.count - a.count), [reservations]);

  if (loading) return <div className="admin-state"><div className="spinner" /><p>جارٍ التحقق من صلاحية الدخول…</p></div>;
  if (!user) return <div className="admin-state"><div className="admin-login-card"><span className="welcome-icon"><ShieldCheck size={28} /></span><span className="section-kicker">مساحة محمية</span><h1>لوحة المسؤولة</h1><p>أدخلي كلمة مرور الإدارة للوصول إلى الحجوزات.</p><form onSubmit={async e=>{e.preventDefault();setLoginError('');try{await login(password)}catch(err:any){setLoginError(err?.message||'كلمة المرور غير صحيحة.')}}}><input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="كلمة المرور" required style={{width:'100%',marginBottom:12}} />{loginError&&<p style={{color:'#b42318'}}>{loginError}</p>}<Button type="submit" disabled={loading}><LogIn size={17} /> تسجيل الدخول</Button></form><a href="/" className="back-link"><ChevronLeft size={16} /> العودة إلى صفحة الحجز</a></div></div>;
  if (!isAdmin) return <div className="admin-state"><div className="admin-login-card"><span className="welcome-icon warning"><ShieldCheck size={28} /></span><span className="section-kicker">لا توجد صلاحية</span><h1>هذه المساحة للمسؤولة فقط</h1><p>الحساب الحالي مسجّل، لكنه لا يملك دور إدارة الحجوزات.</p><Button variant="outline" onClick={() => logout()}><LogOut size={17} /> تسجيل الخروج</Button><a href="/" className="back-link"><ChevronLeft size={16} /> العودة إلى صفحة الحجز</a></div></div>;

  const summaryText = view === "day" ? formatDate(range.from) : formatWeek(range.from, range.to);
  const confirmDelete = (reservation: Reservation) => { if (window.confirm(`هل تريدين إلغاء حجز ${reservation.teacherName} في الحصة ${reservation.lesson}؟`)) remove.mutate({ id: reservation.id }); };
  return <div className="site-shell admin-shell"><header className="topbar page-width"><div className="header-ministry official-logo"><img src="/assets/ministry-education-oman-new.png" alt="وزارة التعليم" /></div><a className="brand-lockup centered-brand" href="/" aria-label="الصفحة الرئيسية"><span className="school-mark school-mark-center"><img src="/assets/school-logo-new.png" alt="شعار مدرسة ضباب" /></span></a><div className="header-vision official-logo"><img src="/assets/oman-vision-2040-cropped.png" alt="رؤية عُمان 2040" /><div className="admin-user"><span className="user-avatar">{(user.name ?? "م").slice(0, 1)}</span><span>{user.name ?? "المسؤولة"}</span><button onClick={() => logout()} aria-label="تسجيل الخروج"><LogOut size={17} /></button></div></div></header><main className="page-width admin-content"><div className="admin-heading"><div><span className="eyebrow"><ShieldCheck size={16} /> إدارة آمنة</span><h1>مرحبًا، {user.name ?? "أهلًا بكِ"}</h1><p>تابعي حجوزات المركز وعدّليها بسهولة من مكان واحد.</p></div><a href="/" className="outline-link"><ChevronLeft size={17} /> صفحة الحجز</a></div><div className="admin-toolbar"><div className="view-tabs"><button className={view === "day" ? "active" : ""} onClick={() => setView("day")}>اليوم</button><button className={view === "week" ? "active" : ""} onClick={() => setView("week")}>هذا الأسبوع</button></div><label className="toolbar-date"><CalendarDays size={17} /><input type="date" value={anchorDate} onChange={event => setAnchorDate(event.target.value)} /></label><label className="search-box"><Search size={17} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="بحث بالمعلمة أو الصف…" /></label><Button className="export-button" variant="outline" onClick={() => { void exportReservationsToExcel(reservations, view, range.from, range.to); }} disabled={!reservations.length}><Download size={16} /> تصدير Excel</Button><Button className="export-button pdf-button" variant="outline" onClick={() => printReservationsToPdf(reservations, view, range.from, range.to)} disabled={!reservations.length}><FileText size={16} /> تقرير PDF</Button></div><div className="admin-summary"><div className="summary-card"><span className="summary-icon teal"><CalendarDays size={20} /></span><div><strong>{reservations.length}</strong><span>حجز في العرض الحالي</span></div></div><div className="summary-card"><span className="summary-icon gold"><UsersRound size={20} /></span><div><strong>{new Set(reservations.map(item => item.teacherName)).size}</strong><span>معلمة</span></div></div><div className="summary-card"><span className="summary-icon coral"><ShieldCheck size={20} /></span><div><strong>{view === "day" ? 7 - reservations.length : "—"}</strong><span>حصة متاحة اليوم</span></div></div></div><section className="insights-grid"><div className="chart-card"><div className="chart-heading"><div><span className="section-kicker">قراءة سريعة</span><h2>{view === "day" ? "توزيع حجوزات الحصص" : "الحجوزات خلال الأسبوع"}</h2></div><span className="chart-total">{reservations.length} إجمالي</span></div><div className="bar-chart">{chartData.map(item => <div className="bar-column" key={item.label}><span className="bar-value">{item.count || ""}</span><div className="bar-track"><span className="bar-fill" style={{ height: `${(item.count / maxChartCount) * 100}%` }} /></div><small>{item.label}</small></div>)}</div></div><div className="chart-card usage-card"><div className="chart-heading"><div><span className="section-kicker">الأكثر استخدامًا</span><h2>أنواع الحجز</h2></div><span className="chart-total">خيارات</span></div><div className="usage-list">{usageStats.map(item => <div className="usage-row" key={item.option}><div><span>{item.option}</span><b>{item.count}</b></div><div className="usage-track"><span style={{ width: `${reservations.length ? (item.count / reservations.length) * 100 : 0}%` }} /></div></div>)}</div></div></section><section className="admin-table-card"><div className="table-head"><div><span className="section-kicker">{view === "day" ? "الحجوزات اليومية" : "ملخص أسبوعي"}</span><h2>{summaryText}</h2></div><span className="table-count">{reservations.length} حجز</span></div>{query.isLoading ? <div className="table-empty"><div className="spinner" /><p>جارٍ تحميل الحجوزات…</p></div> : reservations.length === 0 ? <div className="table-empty"><CalendarDays size={32} /><h3>لا توجد حجوزات هنا</h3><p>ستظهر الحجوزات الجديدة في هذه القائمة مباشرة.</p></div> : <div className="reservations-table"><div className="table-row table-header"><span>التاريخ</span><span>الحصة</span><span>المعلمة والصف</span><span>عنوان الدرس / المادة</span><span>البريد الإلكتروني</span><span>نوع الاستخدام</span><span>ملاحظات</span><span>إجراء</span></div>{reservations.map(item => <div className="table-row" key={item.id}><span className="table-date">{view === "week" ? formatDate(item.bookingDate) : "اليوم"}</span><span><b className="lesson-pill">{item.lesson}</b></span><span><strong>{item.teacherName}</strong><small>{item.grade}</small></span><span className="lesson-title-cell">{item.lessonTitle || "—"}</span><span className="email-cell">{item.email || "—"}</span><span className="tag-list">{item.resourceOptions.map(option => <i key={option}>{option}</i>)}</span><span className="notes-cell">{item.notes || "—"}</span><span className="row-actions"><button onClick={() => setEditing(item)} aria-label="تعديل"><Edit3 size={16} /></button><button className="danger" onClick={() => confirmDelete(item)} aria-label="إلغاء"><Trash2 size={16} /></button></span></div>)}</div>}</section></main>{editing && <EditForm reservation={editing} onClose={() => setEditing(null)} onSaved={() => utils.reservations.adminList.invalidate()} />}</div>;
}
