import { int, mysqlTable, text, timestamp, uniqueIndex, varchar } from "drizzle-orm/mysql-core";

/** Core Manus OAuth user table. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: varchar("role", { length: 32 }).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

/** A single active library booking. The unique key is the concurrency guard. */
export const reservations = mysqlTable(
  "reservations",
  {
    id: int("id").autoincrement().primaryKey(),
    bookingDate: varchar("bookingDate", { length: 10 }).notNull(),
    lesson: int("lesson").notNull(),
      teacherName: varchar("teacherName", { length: 120 }).notNull(),
      grade: varchar("grade", { length: 80 }).notNull(),
      lessonTitle: varchar("lessonTitle", { length: 200 }).notNull().default(""),
      email: varchar("email", { length: 320 }),
      notes: text("notes"),
    resourceOptions: varchar("resourceOptions", { length: 255 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => ({
    bookingSlotUnique: uniqueIndex("reservations_booking_slot_unique").on(
      table.bookingDate,
      table.lesson,
    ),
  }),
);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Reservation = typeof reservations.$inferSelect;
export type InsertReservation = typeof reservations.$inferInsert;
