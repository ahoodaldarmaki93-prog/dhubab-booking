CREATE TABLE IF NOT EXISTS `reservations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookingDate` varchar(10) NOT NULL,
	`lesson` int NOT NULL,
	`teacherName` varchar(120) NOT NULL,
	`grade` varchar(80) NOT NULL,
	`notes` text,
	`resourceOptions` varchar(255) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reservations_id` PRIMARY KEY(`id`),
	CONSTRAINT `reservations_booking_slot_unique` UNIQUE(`bookingDate`,`lesson`)
);
--> statement-breakpoint
ALTER TABLE `users` MODIFY COLUMN `role` varchar(32) NOT NULL DEFAULT 'user';
