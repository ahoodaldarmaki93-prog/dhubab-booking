import { fetchRequestHandler } from '@trpc/server/adapters/fetch';
import { appRouter } from './server/routers';
import { createContext } from './server/_core/context';
import { ensureReservationSchema, initDatabase } from './server/db';

export interface Env {
  DB: D1Database;
  ADMIN_PASSWORD: string;
  SESSION_SECRET: string;
  ASSETS: Fetcher;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    initDatabase(env.DB);
    const url = new URL(request.url);
    if (url.pathname.startsWith('/api/trpc')) {
      await ensureReservationSchema();
      const response = await fetchRequestHandler({ endpoint: '/api/trpc', req: request, router: appRouter, createContext: ({}) => createContext({ req: request, env }), responseMeta: ({ ctx }) => ({ headers: ctx?.responseHeaders }) }); return response;
    }
    if (url.pathname === '/api/health') {
      return Response.json({ status: 'ok' });
    }
    return env.ASSETS.fetch(request);
  },
};
