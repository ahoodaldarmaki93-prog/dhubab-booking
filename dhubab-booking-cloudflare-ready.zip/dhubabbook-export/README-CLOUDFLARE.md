# حجز مركز مصادر التعلّم – نسخة Cloudflare

هذه نسخة مجهزة للنقل من Manus إلى Cloudflare Workers + D1.

## قبل النشر
1. أنشئي D1 باسم `dhubab-booking-db`.
2. انسخي `database_id` إلى `wrangler.jsonc` بدل `REPLACE_WITH_D1_DATABASE_ID`.
3. غيّري `ADMIN_PASSWORD` إلى كلمة مرور قوية.
4. غيّري `SESSION_SECRET` إلى قيمة عشوائية طويلة.
5. نفذي `npm install` ثم `npm run build` ثم `npx wrangler deploy`.

الحجوزات الجديدة تبدأ من قاعدة D1 فارغة، مع بقاء منع تكرار نفس التاريخ والحصة.
