import { TRPCError } from '@trpc/server';
import { z } from 'zod';
import { adminProcedure, publicProcedure, router, createSession, sessionCookie, clearSessionCookie } from './_core/trpc';
import { createReservation, deleteReservation, getPublicAvailability, listReservations, ReservationConflictError, updateReservation } from './db';

const resourceOption=z.enum(['القراءة','استخدام الأجهزة','استخدام الشاشة','أخرى']);
const reservationInput=z.object({bookingDate:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),lesson:z.number().int().min(1).max(7),teacherName:z.string().trim().min(2).max(120),grade:z.string().trim().min(1).max(80),lessonTitle:z.string().trim().min(2).max(200),email:z.string().trim().email().max(320).optional().or(z.literal('')),notes:z.string().trim().max(1000).optional().or(z.literal('')),resourceOptions:z.array(resourceOption).min(1).max(2)});
const dateRange=z.object({from:z.string(),to:z.string(),search:z.string().max(120).optional()});

export const appRouter=router({
 auth:router({
  me:publicProcedure.query(({ctx})=>ctx.user),
  login:publicProcedure.input(z.object({password:z.string().min(1)})).mutation(async({input,ctx})=>{if(!ctx.env.ADMIN_PASSWORD || input.password!==ctx.env.ADMIN_PASSWORD) throw new TRPCError({code:'UNAUTHORIZED',message:'كلمة المرور غير صحيحة.'}); const token=await createSession(ctx.env.SESSION_SECRET); ctx.responseHeaders.set('Set-Cookie',sessionCookie(token)); return {success:true};}),
  logout:publicProcedure.mutation(({ctx})=>{ctx.responseHeaders.set('Set-Cookie',clearSessionCookie());return {success:true};}),
 }),
 reservations:router({
  availability:publicProcedure.input(z.object({bookingDate:z.string()})).query(({input})=>getPublicAvailability(input.bookingDate)),
  create:publicProcedure.input(reservationInput).mutation(async({input})=>{try{return await createReservation(input)}catch(e){if(String(e).toLowerCase().includes('unique'))throw new TRPCError({code:'CONFLICT',message:'هذه الحصة محجوزة مسبقًا، اختاري حصة أخرى.'});throw new TRPCError({code:'INTERNAL_SERVER_ERROR',message:'تعذر حفظ الحجز الآن. حاولي مرة أخرى.'});}}),
  adminList:adminProcedure.input(dateRange).query(({input})=>listReservations(input)),
  adminUpdate:adminProcedure.input(z.object({id:z.number().int().positive(),data:reservationInput})).mutation(async({input})=>{try{await updateReservation(input.id,input.data);return {success:true}}catch(e){if(String(e).toLowerCase().includes('unique'))throw new TRPCError({code:'CONFLICT',message:'التعديل تعارض مع حجز موجود في اليوم والحصة نفسيهما.'});throw new TRPCError({code:'INTERNAL_SERVER_ERROR',message:'تعذر تعديل الحجز.'});}}),
  adminDelete:adminProcedure.input(z.object({id:z.number().int().positive()})).mutation(async({input})=>{await deleteReservation(input.id);return {success:true}}),
 })
});
export type AppRouter=typeof appRouter;
