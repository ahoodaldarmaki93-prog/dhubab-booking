import { SignJWT, jwtVerify } from 'jose';

export type AppUser = { id: number; openId: string; name: string; email: string | null; role: 'admin' };

const COOKIE = 'dhubab_admin';
const ONE_YEAR = 60 * 60 * 24 * 365;

const key = (secret: string) => new TextEncoder().encode(secret);

export async function createSession(secret: string): Promise<string> {
  return new SignJWT({ role: 'admin', name: 'عهود الدرمكي' })
    .setProtectedHeader({ alg: 'HS256', typ: 'JWT' })
    .setIssuedAt()
    .setExpirationTime(`${ONE_YEAR}s`)
    .sign(key(secret));
}

export async function getAdminUserFromRequest(req: Request, secret: string): Promise<AppUser | null> {
  const cookie = req.headers.get('Cookie') ?? '';
  const match = cookie.match(new RegExp(`(?:^|;\\s*)${COOKIE}=([^;]+)`));
  if (!match?.[1]) return null;
  try {
    const { payload } = await jwtVerify(match[1], key(secret), { algorithms: ['HS256'] });
    if (payload.role !== 'admin') return null;
    return { id: 1, openId: 'cloudflare-admin', name: 'عهود الدرمكي', email: null, role: 'admin' };
  } catch { return null; }
}

export function sessionCookie(token: string): string {
  return `${COOKIE}=${token}; Path=/; Max-Age=${ONE_YEAR}; HttpOnly; Secure; SameSite=Lax`;
}
export function clearSessionCookie(): string {
  return `${COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`;
}
