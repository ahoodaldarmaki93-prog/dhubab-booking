import { trpc } from '@/lib/trpc';
import { useCallback, useMemo } from 'react';
export function useAuth(){
 const utils=trpc.useUtils(); const me=trpc.auth.me.useQuery(undefined,{retry:false,refetchOnWindowFocus:false});
 const loginMutation=trpc.auth.login.useMutation({onSuccess:()=>utils.auth.me.invalidate()});
 const logoutMutation=trpc.auth.logout.useMutation({onSuccess:()=>utils.auth.me.setData(undefined,null)});
 const login=useCallback((password:string)=>loginMutation.mutateAsync({password}),[loginMutation]);
 const logout=useCallback(async()=>{await logoutMutation.mutateAsync();await utils.auth.me.invalidate()},[logoutMutation,utils]);
 return useMemo(()=>({user:me.data??null,loading:me.isLoading||loginMutation.isPending||logoutMutation.isPending,error:me.error??null,login,logout,refresh:()=>me.refetch()}),[me.data,me.isLoading,me.error,loginMutation.isPending,logoutMutation.isPending,login,logout,me.refetch]);
}
